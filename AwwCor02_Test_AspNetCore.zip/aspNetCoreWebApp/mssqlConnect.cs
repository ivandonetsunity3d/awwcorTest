﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace aspNetCoreWebApp
{
    public class mssqlConnect
    {
        private string mssqlConnectionString = "data source=awwcor.samadhi.net.ua;initial catalog=awwcor;persist security info=True;user id=awwcorSqlAdmin;password=B1lLG3dzSQLG0dMod30n;MultipleActiveResultSets=True;App=EntityFramework";

        public class Ad
        {
            public string categoryId;
            public string id;
            public string title;
            public string description;
            public string price;
            public string pictureURL;
            public string pictureURL2;
            public string pictureURL3;
            public string dateTime;
            public string author;
            public bool? isVisible;
        }


        //ServicesAdd
        public string AdsAdd(Ad ad)
        {
            System.Data.SqlClient.SqlConnection connection = new SqlConnection(mssqlConnectionString);
            connection.Open();

            //INSERT [awwcorSqlAdmin].[Ads] ([categoryId], [id], [title], [description], [price], [pictureURL], [pictureURL2], [pictureURL3], [dateTime], [author], [isVisible]) VALUES (N'Jobs', N'ABP', N'Middle/Middle+ C#/.NET Engineer', N'Необходимые навыки — Опыт от 2 лет — Знание технологий: .NET/C#, ASP.NET MVC, MVVM, WPF, SQL Server (T-SQL), NoSQL, IIS, Git — Понимание работы протоколов: TCP, DNS — Знание английского на уровне чтения технической литературы — Суперспособность внятно доносить свои мысли устно и письменно: работать придется в большом коллективе, поэтому правильная коммуникация очень важна; — Внимание к деталям, высокий уровень самоорганизации, проактивность, желание постоянно изучать новое.  Будет плюсом — Особенно пригодятся знания и опыт работы с SEO; — Очень важен опыт работы с облаком Microsoft Azure или AWS; — Опыт в разработке низкоуровневых, производительных, мультипоточных приложений; — Опыт в отладке и оптимизации веб-приложений и баз данных; — Опыт в нагрузочном тестировании; — Опыт в e-commerce и/или в продуктовой разработке;', N'1 600 - 3 500 $', N'abp.png', NULL, NULL, NULL, N'ABP', NULL)


            string queryString =
            "insert into Ads ([categoryId], [id], [title], [description], [price], [pictureURL], [pictureURL2], [pictureURL3], [dateTime], [author], [isVisible]) values (N'" +
            ad.categoryId + "', N'" +
            ad.id + "', N'" +
            ad.title + "', N'" +
            ad.description + "', N'" +
            ad.price + "', N'" +
            ad.pictureURL + "', N'" +
            ad.pictureURL2 + "', N'" +
            ad.pictureURL2 + "', N'" +
            ad.dateTime + "', N'" +
            ad.author + "', N'" +
            ad.isVisible.ToString() + "')";

            try
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                int resultRowsAffected = command.ExecuteNonQuery();
                connection.Close();
                return "Added DB records: " + resultRowsAffected.ToString();
            }
            catch (Exception x)
            {
                //throw;
                return x.Message.ToString();
            }
        }

        public Ad SelectAdSimple(string adId)
        {
            Ad ad = new Ad();

            System.Data.SqlClient.SqlConnection connection = new SqlConnection(mssqlConnectionString);
            connection.Open();

            string queryString =
              "SELECT [pictureURL], [title], [price], [dateTime] FROM Ads where id='" + adId + "'";
            SqlCommand command = new SqlCommand(queryString, connection);

            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    ad.pictureURL = reader[0].ToString();
                    ad.title = reader[1].ToString();
                    ad.price = reader[2].ToString();
                    ad.dateTime = reader[3].ToString();
                }
            }
            connection.Close();


            return ad;
        }

        //прочитать все id у объявлений
        public List<string> ReadIds()
        {
            List<string> ids = new List<string>();

            System.Data.SqlClient.SqlConnection connection = new SqlConnection(mssqlConnectionString);
            connection.Open();

            string queryString = "SELECT [id] FROM [Ads]";
            SqlCommand command = new SqlCommand(queryString, connection);

            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    ids.Add(reader[0].ToString());                  
                }
            }
            connection.Close();

            return ids;

        }

        public Ad SelectAdAllDetails(string adId)
        {
            Ad ad = new Ad();

            System.Data.SqlClient.SqlConnection connection = new SqlConnection(mssqlConnectionString);
            connection.Open();

            string queryString =
              "SELECT [categoryId],[id],[title],[description],[price],[pictureURL],[pictureURL2],[pictureURL3],[dateTime],[author],[isVisible] FROM Ads where id='" + adId + "'";
            SqlCommand command = new SqlCommand(queryString, connection);

            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    ad.categoryId = reader[0].ToString();
                    ad.id = reader[1].ToString();
                    ad.title = reader[2].ToString();
                    ad.description = reader[3].ToString();
                    ad.price = reader[4].ToString();
                    ad.pictureURL = reader[5].ToString();
                    ad.pictureURL2 = reader[6].ToString();
                    ad.pictureURL3 = reader[7].ToString();
                    ad.dateTime = reader[8].ToString();
                    ad.author = reader[9].ToString();
                    string strIsVisible = reader[10].ToString();
                    if (!string.IsNullOrWhiteSpace(strIsVisible))
                    {
                        ad.isVisible = Convert.ToBoolean(strIsVisible);
                    }
                    else { ad.isVisible = false; }
                }
            }
            connection.Close();


            return ad;
        }




        public List<Ad> AdsReadSimple(string orderBy, string ascDesc)
        {
            List<Ad> ads = new List<Ad>();

            System.Data.SqlClient.SqlConnection connection = new SqlConnection(mssqlConnectionString);
            connection.Open();

            //  order by [dateTime] desc
            //  order by [dateTime] asc
            //  order by price desc
            //  order by price asc

            if (string.IsNullOrEmpty(orderBy)) orderBy = "price";
            if (string.IsNullOrEmpty(ascDesc)) ascDesc = "asc";

            string queryString =
               "SELECT [pictureURL], [title], [price], [dateTime], [id] FROM Ads order by " + orderBy + " " + ascDesc;// where language='uk'";
            SqlCommand command = new SqlCommand(queryString, connection);
            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    Ad ad = new Ad();
                    ad.pictureURL = reader[0].ToString();
                    ad.title = reader[1].ToString();
                    ad.price = reader[2].ToString();
                    ad.dateTime = reader[3].ToString();
                    ad.id = reader[4].ToString();
                    ads.Add(ad);
                }
            }
            connection.Close();
            return ads;
        }




        public List<Ad> AdsReadDetails(string orderBy, string ascDesc)
        {
            List<Ad> ads = new List<Ad>();

            System.Data.SqlClient.SqlConnection connection = new SqlConnection(mssqlConnectionString);
            connection.Open();

            //  order by [dateTime] desc
            //  order by [dateTime] asc
            //  order by price desc
            //  order by price asc

            if (string.IsNullOrEmpty(orderBy)) orderBy = "price";
            if (string.IsNullOrEmpty(ascDesc)) ascDesc = "asc";

            string queryString =
               "SELECT [categoryId],[id],[title],[description],[price],[pictureURL],[pictureURL2],[pictureURL3],[dateTime],[author],[isVisible] FROM Ads order by " + orderBy + " " + ascDesc; 
            SqlCommand command = new SqlCommand(queryString, connection);
            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    Ad ad = new Ad();
                    ad.categoryId = reader[0].ToString();
                    ad.id = reader[1].ToString();
                    ad.title = reader[2].ToString();
                    ad.description = reader[3].ToString();
                    ad.price = reader[4].ToString();
                    ad.pictureURL = reader[5].ToString();
                    ad.pictureURL2 = reader[6].ToString();
                    ad.pictureURL3 = reader[7].ToString();
                    ad.dateTime = reader[8].ToString();
                    ad.author = reader[9].ToString();
                    string strIsVisible = reader[10].ToString();
                    if (!string.IsNullOrWhiteSpace(strIsVisible))
                    {
                        ad.isVisible = Convert.ToBoolean(strIsVisible);
                    }
                    else { ad.isVisible = false; }
                    ads.Add(ad);
                }
            }
            connection.Close();
            return ads;
        }
    }



}
