using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace aspNetCoreWebApp.Pages
{
    public class ReadAdDetailsModel : PageModel
    {
        public void OnGet()
        {
            string id = Request.Query["id"];
            if (string.IsNullOrEmpty(id)) id = "AWWCORTrainee";
            if (!string.IsNullOrEmpty(id))
            {
                mssqlConnect sqlCon = new mssqlConnect();
                mssqlConnect.Ad adForJson = sqlCon.SelectAdAllDetails(id);

                string adInJson = Newtonsoft.Json.JsonConvert.SerializeObject(adForJson);

                //System.Text.Encoding srcEncoding = Encoding.GetEncoding(1251);
                //System.Text.Encoding dstEncoding = Encoding.UTF8;

                byte[] dataIn1251 = Encoding.GetEncoding(1251).GetBytes(adInJson);
                //byte[] dataInUTF8 = Encoding.Convert(srcEncoding, dstEncoding, dataIn1251);

                //Response.Headers["Content-Type"] += ";charset=utf-8";
                Response.Headers["Content-Type"] += ";charset=1251";

                Response.Body.Write(dataIn1251, 0, dataIn1251.Length);
            }
        }
    }
}
