using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Newtonsoft.Json;

namespace aspNetCoreWebApp.Pages
{
    public class AdCreated
    {
        public string adId = "";
        public string resultCode = "";
    }
    public class CreateAdOKJsonModel : PageModel
    {
        public void ResponseWrite(string writeMe)
        {
            byte[] data = System.Text.Encoding.UTF8.GetBytes(writeMe);
            //      byte[] data = System.Text.Encoding.GetEncoding(1251).GetBytes(writeMe);
            Response.Body.Write(data, 0, data.Length);
        }
        public void OnGet()
        {
            string resultCode = Request.Query["resultCode"];
            string adId = Request.Query["adId"];

            AdCreated adCreated = new AdCreated();
            adCreated.adId = adId;
            adCreated.resultCode = resultCode;

            string adCreatedInJson = JsonConvert.SerializeObject(adCreated);
            ResponseWrite(adCreatedInJson);
        }
    }
}
