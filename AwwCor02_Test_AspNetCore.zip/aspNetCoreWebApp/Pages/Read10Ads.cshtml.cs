using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace aspNetCoreWebApp.Pages
{
    public class Read10AdsModel : PageModel
    {
        public void ResponseWrite(string writeMe)
        {
            byte[] data = System.Text.Encoding.GetEncoding(1251).GetBytes(writeMe);
            Response.Body.Write(data, 0, data.Length);
        }



        public void OnGet()
        {
            int adsPerPage = 10; //10 ads per page
            int pageNumberToShow = Convert.ToInt32(Request.Query["pageNumber"]);
            string orderBy = Request.Query["orderBy"];
            string ascDesc = Request.Query["ascDesc"];

            mssqlConnect sqlCon = new mssqlConnect();
            List<mssqlConnect.Ad> listAds = sqlCon.AdsReadSimple(orderBy, ascDesc);

            int adsQuantity = listAds.Count();

            //��������� ���-�� ������ �������:
            int fullPagesQuantity = adsQuantity / adsPerPage;//10 ads per page

            // ��������� ���-�� ���������� �� ��������� ��������:
            int adsOnLastPage = adsQuantity % adsPerPage;//������� �� ������� ������

            ResponseWrite("<html><body>");

            ResponseWrite("adsQuantity = " + adsQuantity + "<br/>");
            ResponseWrite("fullPagesQuantity = " + fullPagesQuantity + "<br/>");



            ResponseWrite("�������� ���������� �� ��������: <br/>");
            for (int p = 0; p <= (adsQuantity / 10); p++)
            {
                string url =
                    "/Read10Ads?pageNumber=" + p.ToString() +
                    "&orderBy=" + orderBy +
                    "&ascDesc=" + ascDesc;

                ResponseWrite("<a href='" + url + "'>�������� �" + p.ToString() +
                    " (" + url + ")</a> | ");


                string url2 =
                       "/Read10AdsJson?pageNumber=" + p.ToString() +
                       "&orderBy=" + orderBy +
                       "&ascDesc=" + ascDesc;

                ResponseWrite("<a href='" + url2 + "'>� JSON</a><br/><br/>");
            }


            ResponseWrite("<hr/>***page " + pageNumberToShow + "***:<br/>");

            for (int adNumber = 0; adNumber < adsQuantity; adNumber++)
            {
                int pageNumber = adNumber / 10;
                if (pageNumber == pageNumberToShow)
                {
                    mssqlConnect.Ad ad = listAds[adNumber];

                    ResponseWrite("<br/>[" + adNumber 
                        //+ ", pageNumber = " + pageNumber
                        + "] " + ad.id.ToString() + ":");

                    ResponseWrite("<br/>");
                    ResponseWrite("<a href='/ReadAd?id=" + ad.id.ToString() + "'>+ �������� ���������� ����� WebAPI (����������)</a>");

                    ResponseWrite(" | ");
                    ResponseWrite("<a href='/ReadAd?id=" + ad.id.ToString() + "&fields=all'>c ������������� ������ (/ReadAd?id=" + ad.id.ToString() + "&fields=all)</a><br/>");

                    //ResponseWrite("<br/>");
                    //ResponseWrite("<a href='/ReadAdDetails?id=" + ad.id.ToString() + "&fields=all'>�������� ���������� ����� WebAPI c ������������� ������ (/ReadAdDetails?id=" + ad.id.ToString() + "&fields=all)</a>");
                }

            }

            ResponseWrite("<hr/>");
            ResponseWrite("<b>������ ��������� SQL-������:</b><br/>");


            string picturesPath = "/Pictures/";

            ResponseWrite("<table border='1' bordercolor='black' style='width:100%'>");

            for (int adNumber = 0; adNumber < listAds.Count(); adNumber++)
            {
                int pageNumber = adNumber / 10;
                if (pageNumber == pageNumberToShow)
                {
                    mssqlConnect.Ad ad = listAds[adNumber];

                    ResponseWrite("<tr style='background-color: white;vertical-align:central'>");
                    {
                        ResponseWrite("<td style=`width:200px;text-align:center;vertical-align:central` >");
                        {
                            ResponseWrite("<img src='");
                            ResponseWrite(picturesPath + ad.pictureURL);
                            ResponseWrite("' width='100%'  /><br/>");
                        }
                        ResponseWrite("</td>");
                    }

                    ResponseWrite("<td style='text-align:justify'>");
                    {
                        ResponseWrite("<b style='color:darkslateblue'>");
                        ResponseWrite("<h3>");
                        ResponseWrite(ad.title);
                        ResponseWrite("</h3>");
                        ResponseWrite("</b>");
                        ResponseWrite("</td>");
                    }

                    {
                        ResponseWrite("<td style='text-align:center;vertical-align:center;color:darkslateblue'>");
                        ResponseWrite("<br/>");
                        ResponseWrite("<h3 style='text-align:center;vertical-align:center;'>");
                        ResponseWrite(ad.price);
                        ResponseWrite("</h3>");
                        ResponseWrite("<br/>");

                        ResponseWrite("</td>");
                    }

                    {
                        ResponseWrite("<td style='text-align:center;vertical-align:center;color:darkslateblue'>");
                        ResponseWrite("<br/>");
                        ResponseWrite("<h3 style='text-align:center;vertical-align:center;'>");
                        ResponseWrite(ad.dateTime);
                        ResponseWrite("</h3>");
                        ResponseWrite("<br/>");

                        ResponseWrite("</td>");
                    }


                    ResponseWrite("</tr>");



                }

            }
            ResponseWrite("</table>");

            ResponseWrite("</body></html>");


        }
    }
}
