using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Newtonsoft.Json;

namespace aspNetCoreWebApp.Pages
{
    public class ReadAdModel : PageModel
    {
        public void OnGet()
        {
            string id = Request.Query["id"];
            string fields = Request.Query["fields"];

            if (!string.IsNullOrEmpty(id)) 
            {
                mssqlConnect sqlCon = new mssqlConnect();
                mssqlConnect.Ad adForJson = new mssqlConnect.Ad();

                if (fields != null) 
                {
                     adForJson = sqlCon.SelectAdAllDetails(id);
                }
                else 
                {
                    adForJson = sqlCon.SelectAdSimple(id);
                }

                string adInJson = JsonConvert.SerializeObject(adForJson);

                //string text = "ID: " + id;
                //byte[] data = Encoding.UTF8.GetBytes(text);
                byte[] data = System.Text.Encoding.GetEncoding(1251).GetBytes(adInJson);
                //byte[] data = Encoding.UTF8.GetBytes(adInJson);
                //Response.Headers["Content-Type"] += ";charset=utf-8"; 
                Response.Headers["Content-Type"] += ";charset=1251";
                Response.Body.Write(data, 0, data.Length);
            }
        }

      

    }
}
