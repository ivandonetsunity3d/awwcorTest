using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Newtonsoft.Json;

namespace aspNetCoreWebApp.Pages
{
    public class CreateAdModel : PageModel
    {
        public void ResponseWrite(string writeMe)
        {
            byte[] data = System.Text.Encoding.UTF8.GetBytes(writeMe);
            //      byte[] data = System.Text.Encoding.GetEncoding(1251).GetBytes(writeMe);
            Response.Body.Write(data, 0, data.Length);
        }

        public void OnGet()
        {
            string id = Request.Query["id"];
            if (!string.IsNullOrEmpty(id))
            {
                //WebClient net = new WebClient(); net.Encoding = Encoding.UTF8;
                //Response.Headers["Content-Type"] += ";charset=utf-8";

                string title = Request.Query["title"];
                string description = Request.Query["description"];
                string price = Request.Query["price"];
                string author = Request.Query["author"];

                string picture1FileName = Request.Query["picture1"];
                string picture2FileName = Request.Query["picture2"];
                string picture3FileName = Request.Query["picture3"];

                string strDate = DateTime.Now.ToString("yyyy-MM-dd");

                //string txt = title + " | " +
                //    description + " | " +
                //    price + " | " +
                //    author + " | " +
                //    picture1FileName + " | " +
                //    picture2FileName + " | " +
                //    picture3FileName + " | " +
                //    strDate;
                //ResponseWrite(txt);

                mssqlConnect msCon = new mssqlConnect();
                mssqlConnect.Ad ad = new mssqlConnect.Ad();
                ad.id = id;
                ad.title = title;
                ad.description = description;
                ad.price = price;
                ad.author = author;
                ad.pictureURL = picture1FileName;
                ad.pictureURL2 = picture2FileName;
                ad.pictureURL3 = picture3FileName;
                ad.dateTime = strDate;
                ad.isVisible = true;
                ad.categoryId = "Jobs";

                string resultMsg = msCon.AdsAdd(ad);
                string resultCode = "Create Ad result: " + resultMsg;

                //Response.Redirect("/CreateAdOKJson?adId=" + ad.id + "&resultCode=" + resultCode);

                AdCreated adCreated = new AdCreated();
                adCreated.adId = ad.id;
                adCreated.resultCode = resultCode;

                string adCreatedInJson = JsonConvert.SerializeObject(adCreated);

                ResponseWrite(adCreatedInJson);

            }
            //else
            //{
            //    ResponseWrite("id not received ;-(");
            //}

        }
    }
}
