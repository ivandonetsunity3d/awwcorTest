using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace aspNetCoreWebApp.Pages
{
    public class SelectIdsModel : PageModel
    {
        public void OnGet()
        {
            mssqlConnect sqlCon = new mssqlConnect();
            List<string> ids = sqlCon.ReadIds();

            Response.Headers["Content-Type"] += ";charset=1251";

            string txt = "<html><body>������ �� ���������� �� ����� ������: <br/>";
            //byte[] dataTxt = System.Text.Encoding.GetEncoding(1251).GetBytes(txt);
            //Response.Body.Write(dataTxt, 0, dataTxt.Length);

            foreach (string id in ids)
            {
                string idUrl = "<a href='/ReadAdDetails?id=" + id + "'>" + id + "</a> <br/> ";
                //byte[] data = System.Text.Encoding.GetEncoding(1251).GetBytes(idUrl);
                //Response.Body.Write(data, 0, data.Length);
                txt += idUrl;
            }

            //------------------------
            txt += "<hr/>������ �� ���������� (����������� �������������): <br/>";
            //dataTxt = System.Text.Encoding.GetEncoding(1251).GetBytes(txt);
            //Response.Body.Write(dataTxt, 0, dataTxt.Length);
            foreach (string id in ids)
            {
                string idUrl = "<a href='/ReadAd?id=" + id + "'>" + id + "</a> <br/> ";
                //byte[] data = System.Text.Encoding.GetEncoding(1251).GetBytes(idUrl);
                //Response.Body.Write(data, 0, data.Length);
                txt += idUrl;
            }

            txt += "</body><html>";
            byte[] data = System.Text.Encoding.GetEncoding(1251).GetBytes(txt);
            Response.Body.Write(data, 0, data.Length);

        }
    }
}
